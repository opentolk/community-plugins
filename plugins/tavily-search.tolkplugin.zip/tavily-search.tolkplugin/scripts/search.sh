#!/bin/bash
exec /usr/bin/python3 "$(dirname "$0")/search.py"
