#!/bin/bash
exec /usr/bin/python3 "$(dirname "$0")/extract.py"
